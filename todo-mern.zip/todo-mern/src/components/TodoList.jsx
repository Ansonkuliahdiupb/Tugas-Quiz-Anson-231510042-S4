import React from 'react';

const TodoList = ({ todos }) => (
  <ul>
    {todos.map(todo => (
      <li key={todo._id}>
        {todo.text} {todo.completed ? '✅' : ''}
      </li>
    ))}
  </ul>
);

export default TodoList;
